//Funktion som drar vid varje ny sida.
//Den både blurrar ut bakgrunden och "hovrar" in content elementet.
window.onload = function fade() {
	var x = 0;
	var blurScale = 0.1;
	var interval = setInterval(function(){
	x = x+0.1;
	if(x>1.5) {
		blurScale = blurScale*(Math.pow(1.1, 1.1));
		document.getElementById("background").style.filter = ("blur("+blurScale+"px)");

	}
	if(x>1.4 && x<1.6) {
		document.getElementById("mainWindow").style.top = "8%";
		document.getElementById("mainWindow").style.bottom = "8%";
	}
	if(x>1.5 && x<1.7) {
		document.getElementById("mainWindow").style.opacity = "1";
	}
	if(x>4) {
		clearInterval(interval);
		console.log("Fade Finished");
	}
	}, 50);
}
//Används för att automatiskt se vad du har fyllt in i formuläret och sen
//skriver in det i mail meddelandet.
notClicked = true;
function mailAuto() {
	if(notClicked) {
	var mail = document.getElementById("mail");
	var alias = document.getElementById("name").value;
	var discord = document.getElementById("discord").value;
	var size1 = document.getElementById("size1").checked;
	var size2 = document.getElementById("size2").checked;
	var size3 = document.getElementById("size3").checked;
	var size4 = document.getElementById("size4").checked;
	var size5 = document.getElementById("size5").checked;
	var size = "undefined";
	if(size1) {
		size = "25x25";
	}
	if(size2) {
		size = "50x50";
	}
	if(size3) {
		size = "100x100";
	}
	if(size4) {
		size = "250x250";
	}
	if(size5) {
		size = "Custom";
	}
	mail.value = mail.value + "Name: "  + alias + "\n" + "Discord: "  + discord + "\n" + "Size: "  + size + "\n";
	notClicked = false; //Ser till att den inte trycker in allt från formuläret igen vid klick.
	}
}
